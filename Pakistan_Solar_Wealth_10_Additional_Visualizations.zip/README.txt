Household Wealth and Solar Lighting in Pakistan: Ten Additional Visual Investigations

Unzip this package before opening Additional_Visualizations_Gallery.html.
figures/: ten PNG and ten SVG figures.
tables/: ten aggregate CSV tables.
Chart_Titles_and_Captions.csv: titles and reading notes.
