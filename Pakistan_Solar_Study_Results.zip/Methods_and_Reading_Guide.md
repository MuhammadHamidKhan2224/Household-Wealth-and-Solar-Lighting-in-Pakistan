# Methods and reading guide

## Recommended paper framing
Household wealth and two forms of solar lighting in Pakistan: weighted evidence from HIES FY 2024–25.

Report the sample flow and preparation assumptions first, then descriptive contrasts, wealth concentration, adjusted probabilities, and the specified sensitivities. The identifying information supports associations only. Do not interpret solar-only lighting as proof of grid absence.

## Estimation
The denominator is weighted households in each stated domain. Original wealth groups are kept fixed in filtered charts and descriptive bootstrap replicates. Resampling draws PSUs with replacement and retains their households. Concentration-index ranks are recomputed for each replicate, accounting for ties in the continuous asset wealth score.

The binary pseudo-log likelihood is sum_i w_i[y_i log(p_i)+(1-y_i)log(1-p_i)], with p_i=expit(X_i beta). Weights are normalized to mean one. With H=sum_i w_i p_i(1-p_i)X_iX_i', and PSU scores S_g=sum_(i in g)w_i X_i(y_i-p_i), cluster covariance is H^-1(sum_g S_g S_g')H^-1 times G/(G-1)*(n-1)/(n-k). The implementation stops on nonconvergence or a deficient design matrix. Inference uses cluster-based t/F approximations.

Model B is fitted only among solar users. Multiplying its conditional probability by Model A's probability produces coherent hybrid and solar-only probabilities. Joint score covariance allows the model errors to be correlated within PSU. Delta intervals for standardized means condition on the observed weighted covariate distribution; they omit uncertainty in that distribution. They are pointwise intervals, not simultaneous bands. Differences and interactions should be tested directly, not inferred from separate interval overlap.

The urban interaction test concerns joint log-odds interaction coefficients. The corresponding adjusted probability curves show the substantive probability scale; these two scales are different. Model D changes weighting. Model E changes the resource ranking and household group membership. Report all planned results and justify control choices on substantive grounds.

## Reading charts
The gradient chart uses weighted proportions and percentile bootstrap intervals. The resource chart shows weighted medians and the interquartile range of household resource values, not a confidence interval. The heatmap shows outcome prevalence, not household density. Concentration curves rank households from poorer to wealthier; the equality line is a distribution benchmark, not a normative target. E is an Erreygers corrected concentration index for a 0/1 outcome, not the Gini of monetary wealth. The ownership-use matrix compares distinct concepts.

## Data limitations
The workbook is a retained complete-case sample. Missingness in the source records and assumed financial zeros remain substantive limitations even if no Dataset cells are blank. Original sampling strata and finite population corrections are not in the workbook. The notebook cannot restore design information or excluded records. Property and selected financial holdings have partial coverage. Cash receipts have partial coverage. Values are nominal PKR; consumption has no spatial price adjustment or equivalence scale. All monetary per-person denominators use usual household members.

## Official technical references
- WHO, Explorations of inequality, technical notes (concentration curves, binary Erreygers index, and logit interpretation): https://www.who.int/docs/default-source/gho-documents/health-equity/explorations-of-inequality/technical-notes.pdf
- Statsmodels documentation, cluster sandwich covariance: https://www.statsmodels.org/stable/generated/statsmodels.stats.sandwich_covariance.cov_cluster.html (conceptual reference; the notebook uses an explicit implementation).
- Google Colab file input/output: https://colab.research.google.com/notebooks/io.ipynb
- Data definitions and original source references: the supplied workbook's Guide sheet. Its source URLs are retained in the variable dictionary; source provenance is not independently re-established by this notebook.

## Reproducibility
Record the uploaded file's SHA-256 hash, settings, random seed, software versions, and analysis timestamp from run_metadata.json. CSV files contain all numerical results. PNG and SVG figures are in figures/. The interactive HTML works offline and contains aggregate summaries only. Open that file in a browser if an embedded notebook frame does not display.
