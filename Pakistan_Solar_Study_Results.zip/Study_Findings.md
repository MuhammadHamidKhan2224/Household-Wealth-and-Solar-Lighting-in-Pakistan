# Household wealth and solar lighting in Pakistan

Survey round: 2024-25. Retained households: 27,882; PSUs: 2,145. All percentages below use household weights.

## Observed solar lighting

- Any solar: 18.03% (95% interval 16.83–19.30%).
- Grid plus solar: 10.68% (95% interval 9.76–11.60%).
- Solar only: 7.35% (95% interval 6.49–8.10%).

## Wealth patterns

- Any solar: poorest quintile 30.38%, richest quintile 14.16%. Richest minus poorest = -16.22 percentage points (95% PSU-bootstrap interval -19.02 to -13.34). The contrast interval is estimated directly from paired bootstrap replicates.
- Grid plus solar: poorest quintile 5.73%, richest quintile 13.37%. Richest minus poorest = +7.64 percentage points (95% PSU-bootstrap interval +5.75 to +9.58). The contrast interval is estimated directly from paired bootstrap replicates.
- Solar only: poorest quintile 24.65%, richest quintile 0.79%. Richest minus poorest = -23.86 percentage points (95% PSU-bootstrap interval -26.10 to -21.56). The contrast interval is estimated directly from paired bootstrap replicates.

## Wealth-related concentration

- Any solar: Erreygers E=-0.1211 (95% PSU-bootstrap interval -0.1421 to -0.0981); point estimate indicates concentration among poorer households.
- Grid plus solar: Erreygers E=+0.0549 (95% PSU-bootstrap interval +0.0404 to +0.0693); point estimate indicates concentration among wealthier households.
- Solar only: Erreygers E=-0.1760 (95% PSU-bootstrap interval -0.1932 to -0.1576); point estimate indicates concentration among poorer households.

## Adjusted estimates

Model A concerns any solar use. Model B compares hybrid with solar-only lighting among users. Odds ratios describe odds, not percentage-point changes or risk ratios.

- A: Any solar, weighted: wealth_quintile group 5 vs lowest group, adjusted OR 1.231 (95% cluster interval 0.976–1.554).
- D: Any solar, unweighted: wealth_quintile group 5 vs lowest group, adjusted OR 1.269 (95% cluster interval 1.023–1.573).
- E: Consumption-ranking sensitivity: consumption_quintile group 5 vs lowest group, adjusted OR 1.474 (95% cluster interval 1.187–1.830).
- A: Any solar, weighted, All wealth-group coefficients equal zero: F(4, 2144)=20.982, p=5.492e-17.
- B: Hybrid vs solar-only among users, All wealth-group coefficients equal zero: F(4, 1096)=112.582, p=1.926e-80.
- E: Consumption-ranking sensitivity, All wealth-group coefficients equal zero: F(4, 2144)=4.290, p=0.00185.
- C: Wealth × urban, All wealth × urban interactions equal zero: F(4, 2144)=3.793, p=0.004449.

## Interpretation limits

- The source guide records 30123 source households and 2241 exclusions. Original weights remain unchanged after exclusions.
- 27,868 retained households have at least one financial amount assumed zero. This affects the selected financial and partial asset measures; it does not turn a blank original response into a verified observed zero.
- Solar indicators describe lighting, not generation, installed capacity, avoided emissions, affordability, grid reliability, or verified grid access.
- Recorded assets omit some productive assets, livestock, and durable replacement values. Selected cash receipts omit some income sources. Consumption is a nominal research proxy rather than the official poverty aggregate.
- Cross-sectional associations cannot establish wealth causing solar adoption or solar adoption changing wealth.
- PSU resampling and cluster covariance approximate clustering, but cannot reconstruct missing survey strata, official replicate weights, or the excluded households.
